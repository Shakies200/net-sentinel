net_sentinel_v01
----------------
Lightweight cross-platform network sentinel (v0.1).
Lightweight cross-platform network sentinel for Linux (Kali) and Windows — v0.1.

## Quickstart (install locally and run with pipx)
Build and install the project (from project root):

>>>> bash
python -m pip install --upgrade pip build
python -m build
pipx install ./dist/net_sentinel_v01-0.1.0-py3-none-any.whl
